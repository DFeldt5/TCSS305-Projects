/*
Assignment 3 - Bookstore
TCSS 305A
 */

package model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * Cart collects, modifies, and generates total pricing
 * of ItemOrders for the Bookstore application.
 *
 * @author Dustin Feldt
 * @version 27 October 2023
 */
public class Cart {
    /**
     * A system-neutral line break symbol.
     */
    private static final String NEWLINE = System.lineSeparator();

    /**
     * A map to store the ItemOrders.
     */
    private final Map<Item, Integer> myCart;

    /**
     * Represents whether the user has a membership or not.
     */
    private boolean myMembership;

    /**
     * Constructor that initializes a new Cart map.
     */
    public Cart() {
        myCart = new TreeMap<>();
    }

    /**
     * Adds the given order to the cart, or updates quantity if the item already exists.
     *
     * @param theOrder the ItemOrder to be added to the Cart.
     * @throws NullPointerException when the passed order is null.
     */
    public void add(final ItemOrder theOrder) {
        if (theOrder == null) {
            throw new NullPointerException("Orders cannot be null.");
        }
        if (myCart.containsKey(theOrder.getItem())) {
            myCart.replace(theOrder.getItem(), theOrder.getQuantity());
        }
        myCart.put(theOrder.getItem(), theOrder.getQuantity());
    }

    /**
     * Sets the membership to the given boolean.
     *
     * @param theMembership whether the cart has a membership applied.
     */
    public void setMembership(final boolean theMembership) {
        myMembership = theMembership;
    }

    /**
     * Calculates the total price of all orders in the cart.
     *
     * @return the total cost in USD.
     */
    public BigDecimal calculateTotal() {
        BigDecimal totalCost = BigDecimal.valueOf(0.00);

        final Set<Map.Entry<Item, Integer>> orders = myCart.entrySet();
        for (Map.Entry<Item, Integer> entry : orders) {
            final BigDecimal orderCost = calculateOrderCost(entry.getKey(), entry.getValue());
            totalCost = totalCost.add(orderCost);
        }
        return totalCost.setScale(2, RoundingMode.HALF_EVEN);
    }

    /**
     * Helper method for calculateTotal that splits given order into bulk and non-bulk pricing.
     *
     * @param theItem the Item to be priced.
     * @param theQuantity the quantity of the given item.
     * @return the cost of the order, with bulk discount if applicable.
     */
    private BigDecimal calculateOrderCost(final Item theItem, final int theQuantity) {
        int standardQuantity = theQuantity;
        BigDecimal runningCost = BigDecimal.valueOf(0.00);

        if (myMembership) {
            runningCost = runningCost.add(theItem.getBulkPrice().multiply(
                    BigDecimal.valueOf(theQuantity / theItem.getBulkQuantity())));
            runningCost = runningCost.setScale(2, RoundingMode.HALF_EVEN);
            standardQuantity = theQuantity % theItem.getBulkQuantity();
        }
        runningCost = runningCost.add(theItem.getPrice().multiply(
                BigDecimal.valueOf(standardQuantity)));
        return runningCost.setScale(2, RoundingMode.HALF_EVEN);
    }

    /**
     * Empties the cart of all entries.
     */
    public void clear() {
        myCart.clear();
    }

    /**
     * Provides the number of orders in the cart.
     *
     * @return the cart size.
     */
    public int getCartSize() {
        return myCart.size();
    }

    /**
     * Calls ItemOrder toString method on each order in the cart in turn.
     *
     * @return a string representation of the entire cart.
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();

        final Set<Map.Entry<Item, Integer>> orders = myCart.entrySet();
        orders.forEach(entry -> {
            final ItemOrder order = new ItemOrder(entry.getKey(), entry.getValue());
            builder.append(order.toString());
            builder.append(NEWLINE);
        });
        return builder.toString();
    }
}
