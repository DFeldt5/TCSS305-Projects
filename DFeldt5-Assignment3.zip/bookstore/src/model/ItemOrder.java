/*
Assignment 3 - Bookstore
TCSS 305A
 */

package model;

/**
 * Creates ItemOrder objects from Items and provides getter and setter methods.
 *
 * @author Dustin Feldt
 * @version 27 October 2023
 */
public final class ItemOrder {

    /**
     * The Item in the order.
     */
    private Item myItem;

    /**
     * How many such Items are in the order.
     */
    private int myQuantity;

    /**
     * Constructor for ItemOrder objects.
     *
     * @param theItem   the Item to be placed in the order.
     * @param theQuantity   the quantity of that Item.
     */
    public ItemOrder(final Item theItem, final int theQuantity) {
        setItem(theItem);
        setQuantity(theQuantity);
    }

    /**
     * Assigns an item to the order.
     *
     * @param theItem   the Item to be assigned.
     * @throws NullPointerException if the passed Item is null.
     */
    private void setItem(final Item theItem) {
        if (theItem == null) {
            throw new NullPointerException("Item cannot be null.");
        }
        this.myItem = theItem;
    }

    /**
     * Assigns a number to the order quantity.
     *
     * @param theQuantity   the quantity of the Item in this order.
     * @throws IllegalArgumentException when the quantity is negative.
     */
    private void setQuantity(final int theQuantity) {
        if (theQuantity < 0) {
            throw new IllegalArgumentException(
                    theQuantity + " is invalid: Quantity cannot be negative.");
        }
        this.myQuantity = theQuantity;
    }

    /**
     * Retrieves the order's Item.
     *
     * @return this ItemOrder's Item value.
     */
    public Item getItem() {
        return this.myItem;
    }

    /**
     * Retrieves the order's Quantity.
     *
     * @return this ItemOrder's Quantity value.
     */
    public int getQuantity() {
        return this.myQuantity;
    }

    /**
     * Calls Item's toString() method and adds the quantity.
     *
     * @return a String with a description of the item and how many are in the order.
     */
    @Override
    public String toString() {
        return this.getQuantity() + " of " + this.getItem().toString();
    }
}
