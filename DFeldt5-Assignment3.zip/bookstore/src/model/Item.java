/*
Assignment 3 - Bookstore
TCSS 305A
 */

package model;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.Objects;

/**
 * Item describes the attributes and methods of Item objects to
 * be used in the Bookstore.
 *
 * @author Dustin Feldt
 * @version 27 October 2023
 */
public final class Item implements Comparable<Item> {
    /**
     * A US Dollar Number Format object for currency consistency.
     */
    private static final NumberFormat DOLLAR_FORMAT =
            NumberFormat.getCurrencyInstance(Locale.US);

    /**
     * Stand-in default value for Bulk Quantity.
     */
    private static final int DEFAULT_BULK_QUANTITY = 1;

    /**
     * The Item's name.
     */
    private String myName;

    /**
     * The Item's price.
     */
    private BigDecimal myPrice;

    /**
     * The Item's bulk quantity.
     */
    private int myBulkQuantity;

    /**
     * The item's bulk price.
     */
    private BigDecimal myBulkPrice;

    /**
     * Default constructor for non-bulk items.
     *
     * @param theName   The name of the item.
     * @param thePrice  The price of the item.
     */
    public Item(final String theName, final BigDecimal thePrice) {
        this(theName, thePrice, DEFAULT_BULK_QUANTITY, thePrice);
    }

    /**
     * Full constructor for all items.
     *
     * @param theName   The name of the item.
     * @param thePrice  The price of the item.
     * @param theBulkQuantity   The bulk quantity of the item.
     * @param theBulkPrice  The bulk price of the item.
     */
    public Item(final String theName, final BigDecimal thePrice, final int theBulkQuantity,
                final BigDecimal theBulkPrice) {
        setName(theName);
        setPrice(thePrice);
        setBulkQuantity(theBulkQuantity);
        setBulkPrice(theBulkPrice);
    }

    /**
     * Used by the constructor to assign the Name value.
     *
     * @param theName   the String to be assigned to Name.
     * @throws NullPointerException when the passed parameter is null.
     * @throws IllegalArgumentException when the passed parameter is empty.
     */
    private void setName(final String theName) {
        if (theName == null) {
            throw new NullPointerException("Item must have a name.");
        }
        if (theName.isEmpty()) {
            throw new IllegalArgumentException("Item name cannot be empty.");
        }
        this.myName = theName;
    }

    /**
     * Used by the constructor to assign the Price value.
     *
     * @param thePrice  the BigDecimal to be assigned to Price.
     * @throws NullPointerException when the parameter is null.
     * @throws IllegalArgumentException when the parameter is negative.
     */
    private void setPrice(final BigDecimal thePrice) {
        if (thePrice == null) {
            throw new NullPointerException("Price must have a value.");
        }
        if (thePrice.doubleValue() < 0) {
            throw new IllegalArgumentException(
                    thePrice + " is invalid: Price cannot be less than zero.");
        }
        this.myPrice = thePrice;
    }

    /**
     * Used by the constructor to assign the Bulk Quantity value.
     *
     * @param theBulkQuantity   the int to be assigned to Bulk Quantity.
     * @throws IllegalArgumentException when the passed value is zero or negative.
     */
    private void setBulkQuantity(final int theBulkQuantity) {
        if (theBulkQuantity < 1) {
            throw new IllegalArgumentException(
                    theBulkQuantity + " is invalid: Bulk Quantity cannot be less than one.");
        }
        this.myBulkQuantity = theBulkQuantity;
    }

    /**
     * Used by the constructor to assign the Bulk Price.
     *
     * @param theBulkPrice  the BigDecimal to be assigned to Bulk Price.
     * @throws NullPointerException when the passed value is null.
     * @throws IllegalArgumentException when the passed value is negative.
     */
    private void setBulkPrice(final BigDecimal theBulkPrice) {
        if (theBulkPrice == null) {
            throw new NullPointerException("Bulk Price must have a value.");
        }
        if (theBulkPrice.doubleValue() < 0) {
            throw new IllegalArgumentException(
                    theBulkPrice + " is invalid: Bulk Price cannot be less than zero.");
        }
        this.myBulkPrice = theBulkPrice;
    }

    /**
     * Provides the Item's name.
     *
     * @return a String with the item's name.
     */
    public String getName() {
        return this.myName;
    }

    /**
     * Provides the item's price.
     *
     * @return the item's price in USD.
     */
    public BigDecimal getPrice() {
        return this.myPrice;
    }

    /**
     * Provides the item's bulk quantity.
     *
     * @return the item's bulk quantity.
     */
    public int getBulkQuantity() {
        return this.myBulkQuantity;
    }

    /**
     * Provides the item's bulk price.
     *
     * @return the item's bulk price in USD.
     */
    public BigDecimal getBulkPrice() {
        return this.myBulkPrice;
    }

    /**
     * Checks to see if the item has a bulk discount.
     *
     * @return true if bulk quantity is quantity greater than 1, false if not.
     */
    public boolean isBulk() {
        return getBulkQuantity() > 1;
    }

    /**
     * Generates a String description of the item.
     *
     * @return a String containing the item's name, price, bulk quantity, and bulk price.
     */
    @Override
    public String toString() {
        final StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.getName());
        stringBuilder.append(", ");
        stringBuilder.append(DOLLAR_FORMAT.format(this.getPrice()));
        if (this.isBulk()) {
            stringBuilder.append(" (");
            stringBuilder.append(this.getBulkQuantity());
            stringBuilder.append(" for ");
            stringBuilder.append(DOLLAR_FORMAT.format(this.getBulkPrice()));
            stringBuilder.append(")");
        }
        return stringBuilder.toString();
    }

    /**
     * An override of the equals() method.
     *
     * @param theOtherObject    the object to be compared against.
     * @return true if they are the same, false if not.
     */
    @Override
    public boolean equals(final Object theOtherObject) {
        return theOtherObject != null
                && theOtherObject.getClass().getSimpleName().equals("Item")
                && this.compareTo((Item) theOtherObject) == 0;
    }

    /**
     * Sets the ordering of Items as name, price, bulk quantity, bulk price.
     *
     * @param theOtherItem the object to be compared.
     * @return a negative value if less than the passed object,
     *          positive value if greater, and zero if equal
     */
    @Override
    public int compareTo(final Item theOtherItem) {
        int returnValue = this.getName().compareTo(theOtherItem.getName());
        if (returnValue == 0) {
            returnValue = this.getPrice().compareTo(theOtherItem.getPrice());
        }
        if (returnValue == 0) {
            returnValue = this.getBulkQuantity() - theOtherItem.getBulkQuantity();
        }
        if (returnValue == 0) {
            returnValue = this.getBulkPrice().compareTo(theOtherItem.getBulkPrice());
        }
        return returnValue;
    }

    /**
     * Generates a hash for the item.
     *
     * @return the item's hash based on its attributes.
     */
    @Override
    public int hashCode() {
        return Objects.hash(new Object[]{
                this.getName(), this.getPrice(), this.getBulkQuantity(), this.getBulkPrice()});
    }

}
