/*
Assignment 3 - Bookstore
TCSS 305A
 */

package tests;

import model.Item;
import model.ItemOrder;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class ItemOrderTest {

    private ItemOrder myOrder;
    private Item myItem;

    @BeforeEach
    void setUp() {
        myItem = new Item("Test Item", new BigDecimal("1.50"));
        myOrder = new ItemOrder(myItem, 5);
    }

    @Test
    void testConstructorNullItem() {
        try{
            myOrder = new ItemOrder(null, 5);
            fail("Constructor didn't throw Null Pointer Exception");
        }
        catch (NullPointerException npe) {

        }
    }

    @Test
    void testConstructorNegativeQuantity() {
        try{
            myOrder = new ItemOrder(myItem, -5);
            fail("Constructor didn't throw Illegal Argument Exception");
        }
        catch (IllegalArgumentException iae) {

        }
    }

    @Test
    void getItem() {
        assertEquals(myItem, myOrder.getItem(), "Did not properly retrieve Item.");
    }

    @Test
    void getQuantity() {
        assertEquals(5, myOrder.getQuantity(), "Did not properly retrieve Quantity.");
    }

    @Test
    void testToString() {
        assertEquals("5 of Test Item, $1.50", myOrder.toString(), "toString format should be 'Quantity of Item.toString'.");
    }
}