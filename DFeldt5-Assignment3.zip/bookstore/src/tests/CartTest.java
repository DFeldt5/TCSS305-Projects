/*
Assignment 3 - Bookstore
TCSS 305A
 */

package tests;

import model.Cart;
import model.Item;
import model.ItemOrder;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class CartTest {

    private Cart myCart;
    private ItemOrder myOrder;
    private ItemOrder mySecondOrder;
    private ItemOrder myThirdOrder;
    private Item myItem;
    private Item mySecondItem;
    private Item myThirdItem;

    @BeforeEach
    void setUp() {
        myItem = new Item("First Item", new BigDecimal("1.50"));
        mySecondItem = new Item("Second Item", new BigDecimal("2.00"));
        myThirdItem = new Item("Third Item", new BigDecimal("3.00"), 2, new BigDecimal("5.00"));
        myOrder = new ItemOrder(myItem, 5);
        mySecondOrder = new ItemOrder(mySecondItem, 5);
        myThirdOrder = new ItemOrder(myThirdItem, 3);
        myCart = new Cart();

    }

    @Test
    void addThrowsException() {
        try {
            myCart.add(null);
            fail("Should throw a Null Pointer Exception.");
        } catch (NullPointerException npe){

        }
    }

    @Test
    void addReplacesExisting() {
        myCart.add(myOrder);
        mySecondOrder = new ItemOrder(myItem, 2);
        myCart.add(mySecondOrder);
        assertEquals("2 of First Item, $1.50" + System.lineSeparator(), myCart.toString(), "Order quantity should be 2");
    }

    @Test
    void calculateTotalNoMembership() {
        myCart.add(myOrder);
        myCart.add(mySecondOrder);
        myCart.add(myThirdOrder);
        assertEquals(new BigDecimal("26.50"), myCart.calculateTotal(), "Total Cost should be $26.50");
    }

    @Test
    void calculateTotalWithMembership() {
        myCart.setMembership(true);
        myCart.add(myOrder);
        myCart.add(mySecondOrder);
        myCart.add(myThirdOrder);
        assertEquals(new BigDecimal("25.50"), myCart.calculateTotal(), "Total Cost should be $25.50");
    }

    @Test
    void clear() {
        myCart.add(myOrder);
        myCart.clear();
        assertEquals(0, myCart.getCartSize(), "Cart size should be zero after clear");
    }

    @Test
    void getCartSize() {
        myCart.add(myOrder);
        myCart.add(mySecondOrder);
        assertEquals(2, myCart.getCartSize(), "Cart size should be 2");
    }

    @Test
    void testToString() {
        myCart.add(mySecondOrder);
        myCart.add(myThirdOrder);
        myCart.add(myOrder);

        String expected = "5 of First Item, $1.50" + System.lineSeparator()
                + "5 of Second Item, $2.00" + System.lineSeparator()
                + "3 of Third Item, $3.00 (2 for $5.00)" + System.lineSeparator();
        assertEquals(expected, myCart.toString(), "Should print " + expected);
    }
}