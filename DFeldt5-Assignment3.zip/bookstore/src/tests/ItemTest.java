/*
Assignment 3 - Bookstore
TCSS 305A
 */

package tests;

import model.Item;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

class ItemTest {
    private Item myItem;

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
        myItem = new Item("testItem", new BigDecimal("1.50"), 2, new BigDecimal("2.00"));
    }

    @org.junit.jupiter.api.Test
    void testConstructorNullName() {
        try{
            myItem = new Item(null, new BigDecimal("1"));
            fail("Constructor didn't throw Null Pointer Exception");
        }
        catch (NullPointerException npe) {

        }
    }

    @org.junit.jupiter.api.Test
    void testConstructorEmptyName() {
        try{
            myItem = new Item("", new BigDecimal("1"));
            fail("Constructor didn't throw Illegal Argument Exception");
        }
        catch (IllegalArgumentException iae) {

        }
    }

    @org.junit.jupiter.api.Test
    void testConstructorNullPrice() {
        try{
            myItem = new Item("Test Item", null);
            fail("Constructor didn't throw Null Pointer Exception");
        }
        catch (NullPointerException npe) {

        }
    }

    @org.junit.jupiter.api.Test
    void testConstructorNegativePrice() {
        try{
            myItem = new Item("Test Item", new BigDecimal("-1"));
            fail("Constructor didn't throw Illegal Argument Exception");
        }
        catch (IllegalArgumentException iae) {

        }
    }

    @org.junit.jupiter.api.Test
    void testConstructorNegativeBulkQuantity() {
        try{
            myItem = new Item("Test Item", new BigDecimal("1"), -1, new BigDecimal("1"));
            fail("Constructor didn't throw Illegal Argument Exception");
        }
        catch (IllegalArgumentException iae) {

        }
    }

    @org.junit.jupiter.api.Test
    void testConstructorNullBulkPrice() {
        try{
            myItem = new Item("Test Item", new BigDecimal("1"), 1, null);
            fail("Constructor didn't throw Null Pointer Exception");
        }
        catch (NullPointerException npe) {

        }
    }

    @org.junit.jupiter.api.Test
    void testConstructorNegativeBulkPrice() {
        try{
            myItem = new Item("Test Item", new BigDecimal("1"), 1, new BigDecimal("-1"));
            fail("Constructor didn't throw Illegal Argument Exception");
        }
        catch (IllegalArgumentException iae) {

        }
    }

    @org.junit.jupiter.api.Test
    void getName() {
        assertEquals("testItem", myItem.getName(), "Name should be testItem.");
    }

    @org.junit.jupiter.api.Test
    void getPrice() {
        assertEquals(new BigDecimal("1.50"), myItem.getPrice(), "Price should be 1.50.");
    }

    @org.junit.jupiter.api.Test
    void getBulkQuantity() {
        assertEquals(2, myItem.getBulkQuantity(), "Bulk Quantity should be 2.");
    }

    @org.junit.jupiter.api.Test
    void getBulkPrice() {
        assertEquals(new BigDecimal("2.00"), myItem.getBulkPrice(), "Bulk Price should be 2.00.");
    }

    @org.junit.jupiter.api.Test
    void isNotBulk() {
        Item notBulkItem = new Item("Not Bulk", new BigDecimal("2.00"));
        assertEquals(false, notBulkItem.isBulk(), "Item should not be bulk.");
    }

    @Test
    void isBulk() {
        assertEquals(true, myItem.isBulk(), "Item should be bulk.");
    }

    @org.junit.jupiter.api.Test
    void testToStringNotBulk() {
        myItem = new Item("testItem", new BigDecimal("1.50"));
        assertEquals("testItem, $1.50", myItem.toString(), "toString should be in format name, price");
    }

    @Test
    void testToStringBulk() {
        assertEquals("testItem, $1.50 (2 for $2.00)", myItem.toString(),
                "toString should be in format name, price (bulk quantity for bulk price)");
    }

    @org.junit.jupiter.api.Test
    void testEquals() {
        Item equalItem = new Item("testItem", new BigDecimal("1.50"), 2, new BigDecimal("2.00"));
        assertEquals(true, myItem.equals(equalItem), "Items should be equal.");
    }

    @Test
    void testNotEqual() {
        Item diffPriceItem = new Item("testItem", new BigDecimal("3.33"), 2, new BigDecimal("2.00"));
        Item diffBulkPriceItem = new Item("testItem", new BigDecimal("1.50"), 2, new BigDecimal("5.00"));
        assertEquals(false, diffPriceItem.equals(diffBulkPriceItem), "Items should not be equal.");
    }

    @org.junit.jupiter.api.Test
    void compareTo() {
        Item equalItem = new Item("testItem", new BigDecimal("1.50"), 2, new BigDecimal("2.00"));
        assertEquals(0, myItem.compareTo(equalItem), "Equal items should return 0.");
    }
    @Test
    void compareToGreater() {
        Item diffNameItem = new Item("diffName", new BigDecimal("1.50"), 2, new BigDecimal("2.00"));
        assertEquals(true, myItem.compareTo(diffNameItem) > 0, "compareTo should return a positive number.");
    }

    @Test
    void compareToLesser() {
        Item diffBulkPriceItem = new Item("testItem", new BigDecimal("1.50"), 2, new BigDecimal("5.00"));
        assertEquals(-1, myItem.compareTo(diffBulkPriceItem), "compareTo should return -1.");
    }

    @org.junit.jupiter.api.Test
    void testHashCode() {
        Item equalItem = new Item("testItem", new BigDecimal("1.50"), 2, new BigDecimal("2.00"));
        assertEquals(true, myItem.hashCode() == equalItem.hashCode(), "Equal items should have the same hash code.");
    }

    @Test
    void testHashCodeNotEqual() {
        Item otherItem = new Item("Other Item", new BigDecimal("4.00"));
        assertEquals(false, myItem.hashCode() == otherItem.hashCode(), "Different items should have different hash codes.");
    }
}