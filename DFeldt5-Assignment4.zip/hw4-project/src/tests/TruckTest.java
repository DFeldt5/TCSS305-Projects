package tests;

import model.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class TruckTest {

    private Truck test;

    private static final int TRIES_FOR_RANDOMNESS = 50;

    @BeforeEach
    void setUp() {
        test = new Truck(5, 10, Direction.WEST);
    }

    @Test
    void testConstructor() {

        assertEquals(5, test.getX(), "Truck x coordinate not initialized correctly!");
        assertEquals(10, test.getY(), "Truck y coordinate not initialized correctly!");
        assertEquals(Direction.WEST, test.getDirection(), "Truck direction not initialized correctly!");
        assertEquals(0, test.getDeathTime(), "Truck death time not initialized correctly!");
        assertTrue(test.isAlive(), "Truck isAlive() fails initially!");
    }

    @Test
    void collide() {
        final Truck truckTwo = new Truck(5, 10, Direction.EAST);
        test.collide(truckTwo);

        assertTrue(test.isAlive(), "Truck should survive collisions.");
    }

    @Test
    void testSettersAndGetters() {
        test.setX(15);
        assertEquals(15, test.getX(), "X-coordinate did not change properly.");
        test.setY(15);
        assertEquals(15, test.getY(), "Y-coordinate did not change properly.");
        test.setDirection(Direction.SOUTH);
        assertEquals(Direction.SOUTH, test.getDirection(), "Direction did not change properly.");
    }

    @Test
    void getImageFileName() {
        assertEquals("truck.gif", test.getImageFileName(), "Incorrect image file returned.");
    }

    @Test
    void reset() {
        test.setX(15);
        test.setY(15);
        test.setDirection(Direction.SOUTH);
        test.reset();
        assertEquals(5, test.getX(), "X-coordinate did not reset properly.");
        assertEquals(10, test.getY(), "Y-coordinate did not reset properly.");
        assertEquals(Direction.WEST, test.getDirection(), "Direction did not reset properly.");
    }

    @Test
    void testToString() {
        assertEquals("Truck", test.toString(), "Did not return the proper String.");
    }

    @Test
    void canPass() {
        final List<Terrain> validTerrain = new ArrayList<>();
        validTerrain.add(Terrain.STREET);
        validTerrain.add(Terrain.LIGHT);
        validTerrain.add(Terrain.CROSSWALK);

        // test each terrain type as a destination
        for (final Terrain destinationTerrain : Terrain.values()) {
            // try the test under each light condition
            for (final Light currentLightCondition : Light.values()) {
                if (destinationTerrain == Terrain.STREET) {

                    // Trucks can pass STREET under any light condition
                    assertTrue(test.canPass(destinationTerrain, currentLightCondition),
                            "Truck should be able to pass STREET with light " + currentLightCondition);
                } else if (destinationTerrain == Terrain.LIGHT) {

                    // Trucks can pass LIGHT under any light condition
                    assertTrue(test.canPass(destinationTerrain, currentLightCondition),
                            "Truck should be able to pass LIGHT with light " + currentLightCondition);
                } else if (destinationTerrain == Terrain.CROSSWALK) {
                    // Trucks can pass CROSSWALK
                    // if the light is YELLOW or GREEN but not RED

                    if (currentLightCondition == Light.RED) {
                        assertFalse(test.canPass(destinationTerrain, currentLightCondition),
                                "Truck should NOT be able to pass " + destinationTerrain
                                        + ", with light " + currentLightCondition);
                    } else { // light is yellow or red
                        assertTrue(test.canPass(destinationTerrain, currentLightCondition),
                                "Truck should be able to pass " + destinationTerrain
                                        + ", with light " + currentLightCondition);
                    }
                } else if (!validTerrain.contains(destinationTerrain)) {

                    assertFalse(test.canPass(destinationTerrain, currentLightCondition),
                            "Truck should NOT be able to pass " + destinationTerrain
                                    + ", with light " + currentLightCondition);
                }
            }
        }
    }

    @Test
    void chooseDirectionIntersection() {
        final Map<Direction, Terrain> neighbors = new HashMap<Direction, Terrain>();
        neighbors.put(Direction.WEST, Terrain.STREET);
        neighbors.put(Direction.NORTH, Terrain.STREET);
        neighbors.put(Direction.EAST, Terrain.STREET);
        neighbors.put(Direction.SOUTH, Terrain.STREET);

        boolean seenWest = false;
        boolean seenNorth = false;
        boolean seenEast = false;
        boolean seenSouth = false;

        for (int count = 0; count < TRIES_FOR_RANDOMNESS; count++) {
            final Direction d = test.chooseDirection(neighbors);

            if (d == Direction.WEST) {
                seenWest = true;
            } else if (d == Direction.NORTH) {
                seenNorth = true;
            } else if (d == Direction.EAST) { // this should NOT be chosen
                seenEast = true;
            } else if (d == Direction.SOUTH) {
                seenSouth = true;
            }
        }

        assertTrue(seenWest && seenNorth && seenSouth,
                "Truck chooseDirection() fails to select randomly "
                        + "among all possible valid choices!");

        assertFalse(seenEast, "Test chooseDirection() reversed direction when not necessary!");
    }

    @Test
    public void testChooseDirectionDeadEnd() {
        final Map<Direction, Terrain> neighbors = new HashMap<Direction, Terrain>();
        neighbors.put(Direction.WEST, Terrain.TRAIL);
        neighbors.put(Direction.NORTH, Terrain.GRASS);
        neighbors.put(Direction.SOUTH, Terrain.WALL);
        neighbors.put(Direction.EAST, Terrain.STREET); // reverse direction is only valid terrain

        // the Truck must reverse and go EAST
        assertEquals(Direction.EAST, test.chooseDirection(neighbors),
                "Truck chooseDirection() failed "
                + "when reverse was the only valid choice!");
    }
}