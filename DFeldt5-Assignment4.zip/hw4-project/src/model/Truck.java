/*
Assignment 4 - Road Rage
TCSS 305A
 */

package model;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Defines the specific behavior of a Truck-type Vehicle.
 *
 * @author Dustin Feldt
 * @version 13 November 2023
 */
public final class Truck extends AbstractVehicle {

    /**
     * The number of cycles before a dead Truck revives.
     */
    private static final int DEATH_TIME = 0;

    /**
     * Constructor for Truck that calls the AbstractVehicle constructor.
     *
     * @param theX the x-coordinate.
     * @param theY the y-coordinate.
     * @param theDir the facing direction.
     */
    public Truck(final int theX, final int theY, final Direction theDir) {
        super(theX, theY, theDir, DEATH_TIME);
    }

    /**
     * Returns whether or not this Truck may move onto the given type of
     * terrain, when the street lights are the given color.  Trucks may
     * traverse Streets and Lights under any Light condition, and
     * Crosswalks with Green and Yellow lights.
     *
     * @param theTerrain The terrain.
     * @param theLight   The light color.
     * @return whether or not this Truck may move onto the given type of
     * terrain when the street lights are the given color.
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        boolean returnValue = false;
        if (theTerrain == Terrain.STREET || theTerrain == Terrain.LIGHT) {
            returnValue = true;
        } else if (theTerrain == Terrain.CROSSWALK) {
            if (theLight != Light.RED) {
                returnValue = true;
            }
        }
        return returnValue;
    }

    /**
     * Returns the direction this Truck would like to move, based on the given
     * map of the neighboring terrain.  Trucks choose a random non-reverse
     * direction whenever there is a potential turn, but go straight if not.
     * If they cannot turn or go straight, they reverse direction.
     *
     * @param theNeighbors The map of neighboring terrain.
     * @return the direction this Truck would like to move.
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        Direction direction = this.getDirection();
        final Set<Terrain> illegalTerrain = new HashSet<>(Arrays.asList(
                Terrain.GRASS, Terrain.TRAIL, Terrain.WALL));
        if (illegalTerrain.contains(theNeighbors.get(direction))
                && illegalTerrain.contains(theNeighbors.get(direction.left()))
                && illegalTerrain.contains(theNeighbors.get(direction.right()))) {
            direction = direction.reverse();
        } else {
            while (true) {
                final Direction otherDirection = Direction.random();
                if (!otherDirection.equals(direction.reverse())
                        && !illegalTerrain.contains(theNeighbors.get(otherDirection))) {
                    direction = otherDirection;
                    break;
                }
            }
        }
        return direction;
    }
}
