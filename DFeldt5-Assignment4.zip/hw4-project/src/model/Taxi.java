/*
Assignment 4 - Road Rage
TCSS 305A
 */

package model;

/**
 * Defines the specific behavior of a Taxi-type Vehicle.
 *
 * @author Dustin Feldt
 * @version 13 November 2023
 */
public final class Taxi extends Car {

    /**
     * Keeps track of how long a Taxi has been waiting at a Red Light.
     */
    private int myRedLightTimer;

    /**
     * Constructor for Taxi that calls the Car constructor.
     *
     * @param theX the x-coordinate.
     * @param theY the y-coordinate.
     * @param theDir the facing direction.
     */
    public Taxi(final int theX, final int theY, final Direction theDir) {
        super(theX, theY, theDir);
    }

    /**
     * Returns whether or not this Taxi may move onto the given type of
     * terrain, when the street lights are the given color.  Cars may
     * traverse Streets under any light conditions, and Lights or Crosswalks
     * under Green or Yellow Light conditions. However, a Taxi will only
     * remain stopped at a Red Light for three cycles before moving through it.
     *
     * @param theTerrain The terrain.
     * @param theLight   The light color.
     * @return whether or not this Taxi may move onto the given type of
     * terrain when the street lights are the given color.
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        boolean returnValue = theTerrain.equals(Terrain.STREET)
                || theTerrain.equals(Terrain.LIGHT) && !theLight.equals(Light.RED)
                || theTerrain.equals(Terrain.CROSSWALK) && !theLight.equals(Light.RED);
        if (theTerrain.equals(Terrain.CROSSWALK) && theLight.equals(Light.RED)) {
            if (myRedLightTimer == 3) {
                returnValue = true;
            } else {
                myRedLightTimer++;
            }
        }
        if (returnValue) {
            myRedLightTimer = 0;
        }
        return returnValue;
    }
}
