/*
Assignment 4 - Road Rage
TCSS 305A
 */

package model;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Defines the specific behavior of a Bicycle-type Vehicle.
 *
 * @author Dustin Feldt
 * @version 13 November 2023
 */
public final class Bicycle extends AbstractVehicle {

    /**
     * The number of cycles before a dead Bicycle revives.
     */
    private static final int DEATH_TIME = 35;

    /**
     * Contains the specific Terrain types Bicycles cannot traverse.
     */
    private static final Set<Terrain> ILLEGAL_TERRAIN =
            new HashSet<>(Arrays.asList(Terrain.WALL, Terrain.GRASS));

    /**
     * Constructor for Bicycle that calls the AbstractVehicle constructor.
     *
     * @param theX the x-coordinate.
     * @param theY the y-coordinate.
     * @param theDir the facing direction.
     */
    public Bicycle(final int theX, final int theY, final Direction theDir) {
        super(theX, theY, theDir, DEATH_TIME);
    }

    /**
     * Returns whether or not this Bicycle may move onto the given type of
     * terrain, when the street lights are the given color. Bicycles can
     * traverse Trails and Streets under all light conditions, and Lights
     * and Crosswalks during Green Lights.
     *
     * @param theTerrain The terrain.
     * @param theLight   The light color.
     * @return whether or not this Bicycle may move onto the given type of
     * terrain when the street lights are the given color.
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        return !(ILLEGAL_TERRAIN.contains(theTerrain)
                || (theTerrain.equals(Terrain.CROSSWALK) || theTerrain.equals(Terrain.LIGHT))
                        && theLight.equals(Light.RED));
    }

    /**
     * Returns the direction this Bicycle would like to move, based on the given
     * map of the neighboring terrain. Bicycles prefer to move forward on trails,
     * and will turn to face a trail if there is one to the left or right. Otherwise
     * they will move straight if possible, prioritize turning left over right, or
     * reverse if there is no other option.
     *
     * @param theNeighbors The map of neighboring terrain.
     * @return the direction this Bicycle would like to move.
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        Direction newDirection = this.getDirection();
        if (!theNeighbors.get(newDirection).equals(Terrain.TRAIL)) {
            if (theNeighbors.get(newDirection.left()).equals(Terrain.TRAIL)) {
                newDirection = newDirection.left();
            } else if (theNeighbors.get(newDirection.right()).equals(Terrain.TRAIL)) {
                newDirection = newDirection.right();
            } else {
                if (ILLEGAL_TERRAIN.contains(theNeighbors.get(newDirection))) {
                    if (!ILLEGAL_TERRAIN.contains(theNeighbors.get(newDirection.left()))) {
                        newDirection = newDirection.left();
                    } else if (!ILLEGAL_TERRAIN.contains(
                            theNeighbors.get(newDirection.right()))) {
                        newDirection = newDirection.right();
                    } else {
                        newDirection = newDirection.reverse();
                    }
                }
            }
        }
        return newDirection;
    }
}
