/*
Assignment 4 - Road Rage
TCSS 305A
 */

package model;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Defines the specific behavior of a Car-type Vehicle.
 *
 * @author Dustin Feldt
 * @version 13 November 2023
 */
public class Car extends AbstractVehicle {

    /**
     * The number of cycles before a dead Car revives.
     */
    private static final int DEATH_TIME = 15;

    /**
     * Contains the specific Terrain types Cars cannot traverse.
     */
    private static final Set<Terrain> ILLEGAL_TERRAIN = new HashSet<>(
            Arrays.asList(Terrain.GRASS, Terrain.TRAIL, Terrain.WALL));

    /**
     * Constructor for Car that calls the AbstractVehicle constructor.
     *
     * @param theX the x-coordinate.
     * @param theY the y-coordinate.
     * @param theDir the facing direction.
     */
    public Car(final int theX, final int theY, final Direction theDir) {
        super(theX, theY, theDir, DEATH_TIME);
    }

    /**
     * Returns whether or not this Car may move onto the given type of
     * terrain, when the street lights are the given color.  Cars may
     * traverse Streets under any light conditions, Lights under Green
     * or Yellow Light conditions, and Crosswalks during Green lights.
     *
     * @param theTerrain The terrain.
     * @param theLight   The light color.
     * @return whether or not this Car may move onto the given type of
     * terrain when the street lights are the given color.
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        return theTerrain.equals(Terrain.STREET)
                || theTerrain.equals(Terrain.LIGHT) && !theLight.equals(Light.RED)
                || theTerrain.equals(Terrain.CROSSWALK) && theLight.equals(Light.GREEN);
    }

    /**
     * Returns the direction this Car would like to move, based on the given
     * map of the neighboring terrain.  Cars drive straight if possible; if
     * not, they prefer to turn left.  If they cannot turn left, they try to
     * turn right. Otherwise, they reverse.
     *
     * @param theNeighbors The map of neighboring terrain.
     * @return the direction this Car would like to move.
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        Direction direction = this.getDirection();
        //if else?
        if (ILLEGAL_TERRAIN.contains(theNeighbors.get(direction))) {
            if (ILLEGAL_TERRAIN.contains(theNeighbors.get(direction.left()))) {
                if (ILLEGAL_TERRAIN.contains(theNeighbors.get(direction.right()))) {
                    direction = direction.reverse();
                } else {
                    direction = direction.right();
                }

            } else {
                direction = direction.left();
            }
        }
        return direction;
    }
}
