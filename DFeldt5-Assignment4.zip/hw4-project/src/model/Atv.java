/*
Assignment 4 - Road Rage
TCSS 305A
 */

package model;

import java.util.Map;

/**
 * Defines the specific behavior of an ATV-type Vehicle.
 *
 * @author Dustin Feldt
 * @version 13 November 2023
 */
public final class Atv extends AbstractVehicle {

    /**
     * The number of cycles before a dead ATV revives.
     */
    private static final int DEATH_TIME = 25;

    /**
     * Constructor for ATV that calls the AbstractVehicle constructor.
     *
     * @param theX the x-coordinate.
     * @param theY the y-coordinate.
     * @param theDir the facing direction.
     */
    public Atv(final int theX, final int theY, final Direction theDir) {
        super(theX, theY, theDir, DEATH_TIME);
    }

    /**
     * Returns whether or not this ATV may move onto the given type of
     * terrain, when the street lights are the given color.  ATVs can
     * traverse all types of Terrain other than Walls.
     *
     * @param theTerrain The terrain.
     * @param theLight   The light color.
     * @return whether or not this object may move onto the given type of
     * terrain when the street lights are the given color.
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        return !theTerrain.equals(Terrain.WALL);
    }

    /**
     * Returns the direction this ATV would like to move, based on the given
     * map of the neighboring terrain. ATVs move in a random non-reverse direction,
     * unless that would lead them into a Wall.
     *
     * @param theNeighbors The map of neighboring terrain.
     * @return the direction this object would like to move.
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        while (true) {
            final Direction otherDirection = Direction.random();
            if (!otherDirection.equals(this.getDirection().reverse())
                && !theNeighbors.get(otherDirection).equals(Terrain.WALL)) {
                return otherDirection;
            }
        }
    }
}
