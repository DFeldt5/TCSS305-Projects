/*
Assignment 4 - Road Rage
TCSS 305A
 */

package model;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;


/**
 * Defines the specific behavior of a Human-type Vehicle.
 *
 * @author Dustin Feldt
 * @version 13 November 2023
 */
public final class Human extends AbstractVehicle {

    /**
     * The number of cycles before a dead Human revives.
     */
    private static final int DEATH_TIME = 45;

    /**
     * Contains the specific Terrain types Humans cannot traverse.
     */
    private static final Set<Terrain> ILLEGAL_TERRAIN =
            new HashSet<>(Arrays.asList(
                    Terrain.WALL, Terrain.STREET, Terrain.LIGHT, Terrain.TRAIL));

    /**
     * Constructor for Human that calls the AbstractVehicle constructor.
     *
     * @param theX the x-coordinate.
     * @param theY the y-coordinate.
     * @param theDir the facing direction.
     */
    public Human(final int theX, final int theY, final Direction theDir) {
        super(theX, theY, theDir, DEATH_TIME);
    }

    /**
     * Returns whether or not this Human may move onto the given type of
     * terrain, when the street lights are the given color.  Humans may
     * traverse Grass under all Light conditions, and Crosswalks during
     * Red and Yellow Light conditions.
     *
     * @param theTerrain The terrain.
     * @param theLight   The light color.
     * @return whether or not this Human may move onto the given Terrain.
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        return !(ILLEGAL_TERRAIN.contains(theTerrain)
                || theTerrain.equals(Terrain.CROSSWALK) && theLight.equals(Light.GREEN));
    }

    /**
     * Returns the direction this Human would like to move, based on the given
     * map of the neighboring terrain.  Humans will always turn to face a
     * Crosswalk if possible, or will otherwise choose a random, non-reverse
     * direction. Humans will reverse direction if all other directions are
     * invalid.
     *
     * @param theNeighbors The map of neighboring terrain.
     * @return the direction this Human would like to move.
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        Direction direction = this.getDirection();
        if (ILLEGAL_TERRAIN.contains(theNeighbors.get(direction))
                && ILLEGAL_TERRAIN.contains(theNeighbors.get(direction.left()))
                && ILLEGAL_TERRAIN.contains(theNeighbors.get(direction.right()))) {
            direction = direction.reverse();
        } else if (theNeighbors.get(direction.left()).equals(Terrain.CROSSWALK)) {
            direction = direction.left();
        } else if (theNeighbors.get(direction.right()).equals(Terrain.CROSSWALK)) {
            direction = direction.right();
        } else if (!theNeighbors.get(direction).equals(Terrain.CROSSWALK)) {
            while (true) {
                final Direction otherDirection = Direction.random();
                if (!otherDirection.equals(direction.reverse())
                        && !ILLEGAL_TERRAIN.contains(theNeighbors.get(otherDirection))) {
                    direction = otherDirection;
                    break;
                }
            }
        }
        return direction;
    }
}
