/*
Assignment 4 - Road Rage
TCSS 305A
 */

package model;

/**
 * Defines general behaviors for Vehicle objects.
 *
 * @author Dustin Feldt
 * @version 13 November 2023
 */
public abstract class AbstractVehicle implements Vehicle {

    /**
     * The number of cycles remaining before a dead vehicle revives.
     */
    private int myReviveCount;

    /**
     * The total cycles between a vehicle's death and revival.
     */
    private int myDeathTime;

    /**
     * The vehicle's x-coordinate.
     */
    private int myX;

    /**
     * The vehicle's starting x-coordinate.
     */
    private int myStartingX;

    /**
     * The vehicle's y-coordinate.
     */
    private int myY;

    /**
     * The vehicle's starting y-coordinate.
     */
    private int myStartingY;

    /**
     * The vehicle's current direction.
     */
    private Direction myDirection;

    /**
     * The vehicle's starting direction.
     */
    private Direction myStartingDirection;

    /**
     * Constructor for vehicle classes.
     *
     * @param theX the vehicle's x-coordinate.
     * @param theY the vehicle's y-coordinate.
     * @param theDirection the vehicle's direction.
     * @param theDeathTime the vehicle's revival time.
     */
    protected AbstractVehicle(final int theX, final int theY, final Direction theDirection,
                              final int theDeathTime) {
        setX(theX);
        setY(theY);
        setDirection(theDirection);
        setDeathTime(theDeathTime);
        setStartingPosition();
    }

    /**
     * Called when this Vehicle collides with the specified other Vehicle.
     * The vehicle with the larger DeathTime is rendered inactive.
     *
     * @param theOther The other Vehicle.
     */
    @Override
    public void collide(final Vehicle theOther) {
        if (this.isAlive() && theOther.isAlive()
                && this.myDeathTime > theOther.getDeathTime()) {
            myReviveCount = myReviveCount * -1;
        }
    }

    /**
     * Returns the number of updates between this vehicle's death and when it
     * should be revived.
     *
     * @return the number of updates.
     */
    @Override
    public int getDeathTime() {
        return myDeathTime;
    }

    /**
     * Returns the file name of the image for this Vehicle object, such as
     * "car.gif".
     *
     * @return the file name.
     */
    @Override
    public String getImageFileName() {
        final StringBuilder nameBuilder = new StringBuilder(this.toString().toLowerCase());
        if (!this.isAlive()) {
            nameBuilder.append("_dead");
        }
        nameBuilder.append(".gif");
        return nameBuilder.toString();
    }

    /**
     * Returns this Vehicle object's direction.
     *
     * @return the direction.
     */
    @Override
    public Direction getDirection() {
        return myDirection;
    }

    /**
     * Returns this Vehicle object's x-coordinate.
     *
     * @return the x-coordinate.
     */
    @Override
    public int getX() {
        return myX;
    }

    /**
     * Returns this Vehicle object's y-coordinate.
     *
     * @return the y-coordinate.
     */
    @Override
    public int getY() {
        return myY;
    }

    /**
     * Returns whether this Vehicle object is alive and should move on the map.
     *
     * @return true if the object is alive, false otherwise.
     */
    @Override
    public boolean isAlive() {
        return myReviveCount == myDeathTime;
    }

    /**
     * Called by the UI to notify a dead vehicle that 1 movement round has
     * passed, so that it will become 1 move closer to revival.
     */
    @Override
    public void poke() {
        myReviveCount++;
        if (myReviveCount == 0) {
            myReviveCount = myDeathTime;
            myDirection = Direction.random();
        }
    }

    /**
     * Moves this vehicle back to its original position.
     */
    @Override
    public void reset() {
        this.myX = myStartingX;
        this.myY = myStartingY;
        this.myDirection = myStartingDirection;
    }

    /**
     * Sets this object's facing direction to the given value.
     *
     * @param theDir The new direction.
     */
    @Override
    public void setDirection(final Direction theDir) {
        myDirection = theDir;
    }

    /**
     * Sets this object's x-coordinate to the given value.
     *
     * @param theX The new x-coordinate.
     */
    @Override
    public void setX(final int theX) {
        myX = theX;
    }

    /**
     * Sets this object's y-coordinate to the given value.
     *
     * @param theY The new y-coordinate.
     */
    @Override
    public void setY(final int theY) {
        myY = theY;
    }

    /**
     * Provides the name of the Vehicle.
     *
     * @return the Class name of the vehicle.
     */
    @Override
    public String toString() {
        return this.getClass().getSimpleName();
    }

    /**
     * Sets the vehicle's DeathTime value.
     *
     * @param theDeathTime the DeathTime value.
     */
    private void setDeathTime(final int theDeathTime) {
        myDeathTime = theDeathTime;
        myReviveCount = theDeathTime;
    }

    /**
     * Sets the vehicle's initial coordinates and direction.
     */
    private void setStartingPosition() {
        myStartingX = myX;
        myStartingY = myY;
        myStartingDirection = myDirection;
    }
}

